#ifndef __NETWORK_H__
#define __NEWWORK_H__

void showDomain(char *ip);
void showIp(char *domain);

#endif