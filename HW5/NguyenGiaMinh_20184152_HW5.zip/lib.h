#ifndef __LIB_H__
#define __LIB_H__

int isValidIp(char* ip_str);
int isHostName(char *host);
void hostToIp(char *host);
void ipToHost(char *ip);
char* delete_space(char *str,char *result);
#endif