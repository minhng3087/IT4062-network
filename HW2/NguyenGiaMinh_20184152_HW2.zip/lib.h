#ifndef __LIB_H__
#define __LIB_H__

int isValidIp(char* ip_str);
int isHostName(char *host);
void hostToIp(char *host);
void ipToHost(char *ip);

#endif